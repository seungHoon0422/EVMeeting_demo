-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a708.p.ssafy.io    Database: ssafy_web_db
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat_room`
--

DROP TABLE IF EXISTS `chat_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `alive` bit(1) DEFAULT b'1',
  `recent_message` varchar(255) DEFAULT NULL,
  `recent_message_id` bigint DEFAULT NULL,
  `recent_message_time` varchar(255) DEFAULT NULL,
  `userid1` bigint DEFAULT NULL,
  `userid2` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid1` (`userid1`,`userid2`)
) ENGINE=InnoDB AUTO_INCREMENT=1375 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room`
--

LOCK TABLES `chat_room` WRITE;
/*!40000 ALTER TABLE `chat_room` DISABLE KEYS */;
INSERT INTO `chat_room` VALUES (11,_binary '','hello',68,'2022-08-07T07:17:17.292',1,2),(30,_binary '','string',0,'2022-08-07T06:16:47.510',1,3),(32,_binary '','as',144,'2022-08-08T16:31:09.226',1,7),(33,_binary '','asd',107,'2022-08-08T14:28:37.640',1,12),(37,_binary '','hi',597,'2022-08-18T15:45:03.456',21,23),(380,_binary '','nice to meet you',385,'2022-08-14T21:17:23.917',1,5),(651,_binary '','안녕하세요!!',451,'2022-08-15T22:16:02.054',1,15),(770,_binary '',NULL,NULL,'2022-08-16T10:55:23.457',36,37),(789,_binary '','ㅎㅎ',468,'2022-08-16T16:27:27.364',1,18),(795,_binary '',NULL,NULL,'2022-08-16T16:43:49.517',1,8),(1034,_binary '','noce to meet you',491,'2022-08-17T20:42:02.698',1,9),(1118,_binary '','ㅋㅋㅋㅋㅋㅋㅋㅋㅋ',765,'2022-08-18T22:27:13.677',20,42),(1120,_binary '','hi',550,'2022-08-18T14:09:07.123',37,45),(1187,_binary '',NULL,NULL,'2022-08-18T11:48:36.011',1,47),(1217,_binary '','안녕하세요',556,'2022-08-18T15:21:00.920',15,42),(1235,_binary '','ㄲㄲ',585,'2022-08-18T15:22:38.461',1,17),(1239,_binary '','전 벙글입니다 ㅎㅎㅎ',771,'2022-08-18T22:34:46.008',11,42),(1245,_binary '','hihihi',675,'2022-08-18T17:29:36.758',21,22),(1247,_binary '',NULL,NULL,'2022-08-18T16:09:48.283',50,51),(1249,_binary '',NULL,NULL,'2022-08-18T16:15:38.945',51,52),(1347,_binary '','ㅎ',737,'2022-08-18T20:20:59.185',10,11),(1373,_binary '','SSAFY!',783,'2022-08-18T22:42:02.744',42,61);
/*!40000 ALTER TABLE `chat_room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 22:56:45
